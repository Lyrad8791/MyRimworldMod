﻿using Harmony;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Verse;

namespace TribalEssentials_Code {

	[StaticConstructorOnStartup]
	internal static class TribalEssentials_Initializer {
		static TribalEssentials_Initializer() {
			HarmonyInstance harmony = HarmonyInstance.Create("net.rainbeau.rimworld.mod.tribalessentials");
			harmony.PatchAll(Assembly.GetExecutingAssembly());
		}
	}

	[DefOf]
	public static class ThingDefOf {
		public static ThingDef EarthenMounds;
		public static ThingDef Sandbags;
	}

	public class Alert_NeedDefenses : Alert {
		public Alert_NeedDefenses() {
			this.defaultLabel = Translator.Translate("NeedDefenses");
			this.defaultExplanation = Translator.Translate("NeedDefensesDesc");
			this.defaultPriority = AlertPriority.High;
		}
		public override AlertReport GetReport() {
			AlertReport alertReport;
			if ((GenDate.DaysPassed < 2 ? false : GenDate.DaysPassed <= 5)) {
				List<Map> maps = Find.Maps;
				int num = 0;
				while (num < maps.Count) {
					if (!this.NeedDefenses(maps[num])) {
						num++;
					}
					else {
						alertReport = true;
						return alertReport;
					}
				}
				alertReport = false;
			}
			else {
				alertReport = false;
			}
			return alertReport;
		}
		private bool NeedDefenses(Map map) {
			bool flag;
			flag = (map.IsPlayerHome ? !GenCollection.Any<Building>(map.listerBuildings.allBuildingsColonist, (Building b) => ((b.def.building == null || !b.def.building.IsTurret && !b.def.building.isTrap) && (object)b.def != (object)ThingDefOf.Sandbags ? (object)b.def == (object)ThingDefOf.EarthenMounds : true)) : false);
			return flag;
		}
	}

	[HarmonyPatch(typeof(GenConstruct), "CanPlaceBlueprintOver", null)]
	public static class GenConstruct_CanPlaceBlueprintOver {
		public static bool Prefix(BuildableDef newDef, ThingDef oldDef, ref bool __result) {
			ThingDef thingDef = newDef as ThingDef;
			ThingDef thingDef1 = oldDef;
			if (thingDef == null || thingDef1 == null) {
				return true;
			}
			BuildableDef buildableDef = GenConstruct.BuiltDefOf(oldDef);
			ThingDef thingDef2 = buildableDef as ThingDef;
			if (thingDef.building != null && thingDef.building.canPlaceOverWall && thingDef2 != null) {
				if (thingDef2.defName.Equals("WallLog")) {
					__result = true;
					return false;
				}
			}
			return true;
		}
	}

	[HarmonyPatch(typeof(GenConstruct), "BlocksConstruction", null)]
	public static class GenConstruct_BlocksConstruction {
		public static bool Prefix(Thing constructible, Thing t, ref bool __result) {
			ThingDef thingDef;
			if (constructible == null || t == null) {
				return true;
			}
			if (!(constructible is Blueprint)) {
				thingDef = (!(constructible is Frame) ? constructible.def.blueprintDef : constructible.def.entityDefToBuild.blueprintDef);
			}
			else {
				thingDef = constructible.def;
			}
			ThingDef thingDef1 = thingDef.entityDefToBuild as ThingDef;
			if (thingDef1 != null && thingDef1.building != null && thingDef1.building.canPlaceOverWall) {
				if (t.def.defName.Equals("WallLog")) {
					__result = false;
					return false;
				}
			}
			return true;
		}
	}

	[HarmonyPatch(typeof(GenSpawn), "SpawningWipes", null)]
	public static class GenSpawn_SpawningWipes {
		public static bool Prefix(BuildableDef newEntDef, BuildableDef oldEntDef, ref bool __result) {
			ThingDef thingDef = newEntDef as ThingDef;
			ThingDef thingDef1 = oldEntDef as ThingDef;
			if (thingDef == null || thingDef1 == null) {
				return true;
			}
			ThingDef thingDef2 = thingDef.entityDefToBuild as ThingDef;
			if (thingDef1.IsBlueprint) {
				if (thingDef.IsBlueprint) {
					if (thingDef2 != null && thingDef2.building != null && thingDef2.building.canPlaceOverWall) {
						if (thingDef1.entityDefToBuild is ThingDef) {
							if (thingDef1.entityDefToBuild.defName.Equals("WallLog")) {
								__result = false;
								return false;
							}
						}
					}
				}
			}
			return true;
		}
	}

}
